/*
 * Copyright 2016 the Cook-E development team
 *
 * This file is part of Cook-E.
 *
 * Cook-E is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Cook-E is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Cook-E.  If not, see <http://www.gnu.org/licenses/>.
 */



import org.joda.time.Duration;
import org.joda.time.ReadableDuration;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/*
 * Class representing a step in a recipe
 *
 * Every step has a human-readable description, an action category, list of ingredients, and an
 * estimated time the step takes to perform. None of these values may be null.
 *
 * Objects of this class are immutable.
 */
public final class Step {

    /**
     * A human-readable mDescription of the actions involved in this step
     */
    
    private final String mDescription;

    /**
     * The expected time required to complete this step
     */
    
    private final Duration mTime;

    /**
     * The ingredients required for this step
     */
    
    private final List<String> mIngredients;

    /**
     * Whether this step can be done simultaneously
     */
    private final boolean mSimultaneous;

    /**
     * The set of all string patterns in the description
     * that indicates this step can be done simultaneously
     */
    private static final Set<String> SIMULTANEOUS_PATTERNS = Collections.unmodifiableSet(new HashSet<String>() {{
        add("boil");
        add("bake");
        add("microwave");
    }});
    /**
     * Creates a Step
     * @param ingredients the ingredients required for this step
     * @param description a human-readable description of this step
     * @param duration an estimate of the time required to complete this step
     * @param isSimultaneous if this step can be done simultaneously
     * @throws NullPointerException if any parameter is null
     */
    public Step( List<String> ingredients,  String description,
                 ReadableDuration duration, boolean isSimultaneous) {
  
        mDescription = description;
        mTime = duration.toDuration();
        mIngredients = new ArrayList<>(ingredients);
        this.mSimultaneous = isSimultaneous;
    }

    /**
     * Creates a Step without knowing if step can be done simultaneously
     * @param ingredients the ingredients required for this step
     * @param description a human-readable description of this step
     * @param duration an estimate of the time required to complete this step
     * @throws NullPointerException if any parameter is null
     */
    public Step( List<String> ingredients,  String description,
                 ReadableDuration duration) {
        this(ingredients, description, duration, isSimultaneousParser(description));
    }

    /**
     * Identifies if a step can be done simultaneously
     * @param description description of the step
     * @return true if this step can be done simultaneously, false otherwise
     */
    private static boolean isSimultaneousParser( String description) {
        String[] words = description.split("\\s+");
        for (String word : words) {
            String lowerCaseWord = word.toLowerCase(Locale.US);
            for (String pattern : SIMULTANEOUS_PATTERNS) {
                if (lowerCaseWord.contains(pattern)) return true;
            }
        }
        return false;
    }

    /**
     * Returns the description of this step
     * @return the description
     */
    
    public String getDescription() {
        return mDescription;
    }

    /**
     * Returns the duration of this step
     * @return the duration
     */
    
    public ReadableDuration getTime() {
        return mTime;
    }

    /**
     * Returns the duration of this step, truncated to minute precision
     *
     * The behavior of this method is undefined if the number of minutes in the duration of this
     * step is greater than Integer.MAX_VALUE.
     *
     * @return the duration of this step, in minutes
     */
    public int getDurationMinutes() {
        return (int) mTime.getStandardMinutes();
    }

    /**
     * Returns the ingredients that this step requires
     * @return the ingredients
     */
    
    public List<String> getIngredients() {
        return new ArrayList<>(mIngredients);
    }

    /**
     * Returns if this step can be done simultaneously
     * @return true if this step can be done simultaneously
     */
    public boolean isSimultaneous() { return mSimultaneous; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        final Step step = (Step) o;

        if (mSimultaneous != step.mSimultaneous) return false;
        if (!mDescription.equals(step.mDescription)) return false;
        if (!mTime.equals(step.mTime)) return false;
        return mIngredients.equals(step.mIngredients);
    }

    @Override
    public int hashCode() {
        int result = mDescription.hashCode();
        result = 31 * result + mTime.hashCode();
        result = 31 * result + mIngredients.hashCode();
        result = 31 * result + (mSimultaneous ? 1 : 0);
        return result;
    }

    @Override
    public String toString() {
        return "Step{" +
                "mDescription='" + mDescription + '\'' +
                ", mTime=" + mTime +
                ", mIngredients=" + mIngredients +
                ", mSimultaneous=" + mSimultaneous +
                '}';
    }

    
}