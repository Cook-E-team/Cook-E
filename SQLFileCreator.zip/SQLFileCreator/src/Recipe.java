

import org.joda.time.Duration;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/*
 * Represents a recipe
 *
 * Has an ordered list of steps, a title, and an author.
 * No field may be null.
 */
public final class Recipe extends DatabaseObject  {

    /**
     * The steps that this recipe contains
     */
    
    private List<Step> mSteps;
    /**
     * The title of this recipe
     */
    
    private String mTitle;
    /**
     * The author of this recipe
     */
    
    private String mAuthor;

  
    /**
     * Constructor
     *@param title the title of the recipe, must not be null
     *@param author the author of the recipe, must not be null
     *@param steps the list of steps for the recipe, must not be null
     *@throws NullPointerException if any of the parameters passed to it are null
     */
    public Recipe( String title,  String author,  List<Step> steps) {
        super();

        mSteps = new ArrayList<>(steps);
        mTitle = title;
        mAuthor = author;
    }

    /**
     * Creates a deep copy of another recipe. No part of the new recipe will be modifiable from the
     * old one.
     * @param other the recipe to copy from
     */
    public Recipe(Recipe other) {
        // Step, and String are immutable, so they do not need to be copied.
        // The delegated constructor copies the list of steps.
        this(other.getTitle(), other.getAuthor(), other.getSteps());
        setObjectId(other.getObjectId());
    }


    /**
     * Sets the steps in this recipe
     * @param steps the steps to set
     * @throws NullPointerException if steps is null
     */
    public void setSteps( List<Step> steps) {
        mSteps = new ArrayList<>(steps);
    }

    /**
     * Set the ith step in this recipe
     * The original step will be replaced by the new one
     * Do nothing if index is less than 0 or greeter than the max index
     * @param step the step to set
     * @param i the target index of new step, index start from 0
     * @throws NullPointerException if step is null
     */
    public void setStep( Step step, int i) {
        if (i >= 0 && i < mSteps.size()) {
            mSteps.set(i, step);
        }
    }

    /**
     * Add step to end of the list of steps
     * @param step the step to add
     * @throws NullPointerException if step is null
     */
    public void addStep( Step step) {
        mSteps.add(step);
    }
    /**
     * Returns the steps in this recipe
     * @return the steps
     */
    
    public List<Step> getSteps() {
        return new ArrayList<>(mSteps);
    }

    /**
     * Returns a List of all the ingredients required by all the steps of the recipe
     */
    
    public List<String> getIngredients() {
        List<String> ings = new ArrayList<>();
        for (Step s: mSteps) {
            for (String ingredient: s.getIngredients()) {
                ings.add(ingredient);
            }
        }
        return ings;
    }
    /**
     * Returns the total estimated time of all the recipe's mSteps
     */
    
    public Duration getTotalTime() {
        Duration time = Duration.ZERO;
        for (Step s: mSteps) {
            time = time.withDurationAdded(s.getTime(), 1);
        }
        return time;
    }
    
    public String getTitle() {
        return mTitle;
    }
    
    public String getAuthor() {
        return mAuthor;
    }

    /**
     * Remove the ith step in this recipe.
     * All steps after it will be moved one step forward.
     * Doesn't modify recipe if index is less than 0 or greater than max index.
     * @param i the index of step to remove, index starts from 0.
     * @return The removed step if succeeded, null if failed.
     */
    public Step removeStep(int i) {
        if (i >= 0 && i < mSteps.size()) return mSteps.remove(i);
        else return null;
    }

   

    public void setTitle( String title) {
        mTitle = title;
    }

    public void setAuthor( String author) {
        mAuthor = author;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        final Recipe recipe = (Recipe) o;

        if (!mSteps.equals(recipe.mSteps)) return false;
        if (!mTitle.equals(recipe.mTitle)) return false;
        if (!mAuthor.equals(recipe.mAuthor)) return false;
        return true;

    }

    @Override
    public int hashCode() {
        int result = mSteps.hashCode();
        result = 31 * result + mTitle.hashCode();
        result = 31 * result + mAuthor.hashCode();
        return result;
    }

    @Override
    public String toString() {
        return "Recipe{" +
                "mSteps=" + mSteps +
                ", mTitle='" + mTitle + '\'' +
                ", mAuthor='" + mAuthor + '\'' +
                '}';
    }

   

}